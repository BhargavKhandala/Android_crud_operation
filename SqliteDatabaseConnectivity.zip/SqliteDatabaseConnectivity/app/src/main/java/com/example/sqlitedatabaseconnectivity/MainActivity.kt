package com.example.sqlitedatabaseconnectivity

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.sqlitedatabaseconnectivity.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding
    private val dbHelper = DBHelper(this)
    private var getDataLise = mutableListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        addListener()

    }

    private fun addListener() {
        insertData()
        updateData()
        deleteData()
        ShowAllData()
    }

    private fun ShowAllData() {
        getDataInDatabase()
    }

    private fun deleteData() {
        binding.btnDelete.setOnClickListener {
            dbHelper.deleteData(
                binding.edtId.text.toString().trim().toInt()
            )
            cleanText()
            getDataInDatabase()
        }
    }

    private fun updateData() {
        binding.btnUpdate.setOnClickListener {
            if (binding.edtId.text.trim().isNotEmpty()){
            dbHelper.updateData(
                binding.edtId.text.trim().toString().toInt(),
                binding.edtName.text.trim().toString(),
                binding.edtCity.text.trim().toString()
            )
            cleanText()
            getDataInDatabase()}
            else{
                Toast.makeText(this,"Please Enter Id",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun insertData() {
        binding.btnInsert.setOnClickListener {
            dbHelper.insertData(binding.edtName.text.trim().toString(),
                binding.edtCity.text.trim().toString())
            cleanText()
            getDataInDatabase()
            Toast.makeText(this,"Insert Data",Toast.LENGTH_SHORT).show()

        }
           }

    private fun init(){
        getDataLise.clear()
        getDataInDatabase()
    }

    private fun getDataInDatabase() {
        binding.glDisplayData.removeAllViews() // 🛠 Clear existing TextViews
        getDataLise.clear()
        val users  = dbHelper.getAllUsers().toMutableList()
        for (user in users) {
            val userInfo = "${user.id}: ${user.name}, ${user.city}"
            val textView = android.widget.TextView(this).apply {
                text = userInfo
                textSize = 16f
                setPadding(8, 8, 8, 8)
                setOnClickListener {
                    binding.edtName.setText(user.name)
                    binding.edtCity.setText(user.city)
                    binding.edtName.tag = user.id // Save ID for update/delete
                }
            }
            binding.glDisplayData.addView(textView)
        }
    }

    private fun cleanText(){
        binding.edtId.text.clear()
        binding.edtName.text.clear()
        binding.edtCity.text.clear()
    }

}