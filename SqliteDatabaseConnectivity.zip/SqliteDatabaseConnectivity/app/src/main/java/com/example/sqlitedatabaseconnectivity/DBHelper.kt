package com.example.sqlitedatabaseconnectivity

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context : Context) : SQLiteOpenHelper(context, DATABASE_NAME,null, DATABASE_VERSION) {

    companion object{
        const val DATABASE_NAME = "mydatabase.db"
        const val DATABASE_VERSION = 1
        const val TABLE_NAME = "student"
        const val COLUMN_ID= "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_CITY = "city"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = """
            CREATE TABLE $TABLE_NAME(
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_NAME TEXT,
            $COLUMN_CITY TEXT
            )""".trimIndent()
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertData(name : String,city : String): Long {
        val db = writableDatabase
        val value = ContentValues().apply {
            put(COLUMN_NAME,name)
            put(COLUMN_CITY,city)
        }
        return db.insert(TABLE_NAME, null,value)
    }

    fun updateData(id : Int,name :String,city:String): Int {
        val db = writableDatabase
        val value = ContentValues().apply {
            put(COLUMN_NAME,name)
            put(COLUMN_CITY,city)
        }

        return db.update(TABLE_NAME, value,"$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    fun getAllUsers(): List<User> {
        val users = mutableListOf<User>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)
        with(cursor) {
            while (moveToNext()) {
                val id = getInt(getColumnIndexOrThrow(COLUMN_ID))
                val name = getString(getColumnIndexOrThrow(COLUMN_NAME))
                val city = getString(getColumnIndexOrThrow(COLUMN_CITY))
                users.add(User(id, name, city))
            }
            close()
        }
        return users
    }

    fun deleteData(id:Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_NAME,"$COLUMN_ID=?", arrayOf(id.toString()))
    }

}